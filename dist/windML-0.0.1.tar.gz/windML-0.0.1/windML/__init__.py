from windML.oneshot.models.extreme_learning_machine import ELMClassifier
from windML.oneshot.modelfree.matrix_factorisation import MFRClassifier
from windML.fewshot.direct_feedback_alignment.dfa_classifier import DFAClassifier

__version__ = "0.2.4"
