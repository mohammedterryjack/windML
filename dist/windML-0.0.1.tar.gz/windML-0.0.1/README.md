# WindML

![](images/logo.png)


## ChangeLog
- 0.0.1 initial release